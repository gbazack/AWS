AWS Architectures
source: This my Architecture
